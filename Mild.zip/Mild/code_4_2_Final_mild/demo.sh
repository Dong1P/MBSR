












#Train your own images
#python main.py --model EDSR --scale 4 --save EDSR_mild_Final_x4_2_0320_retrain --reset --chop_forward   --pre_train_1 ../experiment/EDSR_bicubic_Final_x4_2_0315_update/model/model_74.pt

# Test your own images
python main.py --scale 4 --data_test MyImage --test_only --save_results --pre_train_1 ../../experiment/EMBSR_mild_Final_x4_2_0320_retrain/model/model_90.pt   --self_ensemble
