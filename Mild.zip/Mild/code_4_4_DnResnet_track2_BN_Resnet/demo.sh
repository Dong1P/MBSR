
# Train your own images
#python main.py --model EMBSR --scale 1 --save DNEDSR__x4_4_0315_track2_ResDnCNN_L1_Final --reset --chop_forward  # 


# Test your own images
python main.py --scale 1 --data_test MyImage --test_only --save_results --pre_train_1 ../../experiment/DNResnet__x4_4_0315_track2_ResDnCNN_L1_Final/model/model_236.pt --self_ensemble

