#

# Train 
#python main.py --model EMBSR --scale 2 --save EMBSR_bicubic_Final_x2_1_0328_track0_test --reset  --pre_train_1 ../../experiment/EDSR_bicubic_Final_x2_1_0328_track0/model/model_60.pt

#
#
#
# Test your own images

#MyImage_making_test_table
python main.py --scale 2 --data_test MyImage --test_only --save_results --pre_train_1 ../../experiment/EMBSR_bicubic_Final_x2_1_0315_update/model/model_74.pt  --self_ensemble



#python main.py --scale 2 --data_test MyImage --test_only --save_results --pre_train_1 ../../experiment/EDSR_bicubic_Final_x2_1_0322_retrain_update/model/model_12.pt  --self_ensemble

