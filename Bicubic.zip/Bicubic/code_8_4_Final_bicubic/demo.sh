
#python main.py --model EDSR --scale 8 --save EDSR_bicubic_Final_x8_4_0315_update --reset --chop_forward   --pre_train_1 ../experiment/EDSR_bicubic_Final_x8_4_0315/model/model_74.pt #  --pre_train_2 ../experiment/EDSR_baseline_x4_2/model/model_268.pt --pre_train_3 ../experiment/EDSR_bicubic_baseline_x8_4_0315_2/model/model_26.pt


# Test your own images
python main.py --scale 8 --data_test MyImage --test_only --save_results --pre_train_1 ../../experiment/EMBSR_bicubic_Final_x8_4_0315_update/model/model_16.pt  --self_ensemble

