
import os
import os.path
import random
import math
import errno

from data import common

import numpy as np
import scipy.misc as misc

import torch
import torch.utils.data as data
from torchvision import transforms

class MyImage_making_test_table(data.Dataset):
    def __init__(self, args, train=False):
        self.args = args
        self.train = False
        self.name = 'MyImage'
        self.scale = args.scale
        self.idx_scale = 0
        #apath = '/home/kky/EDSR-PyTorch/DIV2K/DIV2K_train_LR_bicubic/X8'
        apath_2 = '/home/kky/Dongwon/SuperResolution/Data/Test/set14/x8'
        apath = '/home/kky/Dongwon/SuperResolution/Data/Test/set14/x4'

        self.filelist = []
        self.filelist_2 = []

        for f in sorted(os.listdir(apath)):
            try:
                filename = os.path.join(apath, f)
                print(filename)
                misc.imread(filename)
                self.filelist.append(filename)
            except:
                pass

        for f in sorted(os.listdir(apath_2)):
            try:
                filename = os.path.join(apath_2, f)
                misc.imread(filename)
                print(filename)
                self.filelist_2.append(filename)
            except:
                pass

    def __getitem__(self, idx):
        img_tar = misc.imread(self.filelist[idx])
        img_in = misc.imread(self.filelist_2[idx])
        if len(img_in.shape) == 2:
            img_in = np.expand_dims(img_in, 2)
        if len(img_tar.shape) == 2:
            img_tar = np.expand_dims(img_tar, 2)
        ih,iw,c = img_in.shape
        img_in = img_in[0:ih-2,0:iw-2,:]
        ih,iw,c = img_in.shape
        if ih%2 != 0:
           img_in = img_in[0:ih-1,0:iw,:]
        if iw%2 != 0:
           img_in = img_in[0:ih,0:iw-1,:]
        ih,iw,c = img_in.shape
        scale = 2
        img_tar = img_tar[0:ih * scale, 0:iw * scale, :]
        img_in, img_tar = common.set_channel(img_in, img_tar, self.args.n_colors)
        print(img_in.shape)
        print(img_tar.shape)

        return common.np2Tensor(img_in, img_tar, self.args.rgb_range)

    def __len__(self):
        return len(self.filelist)

    def set_scale(self, idx_scale):
        self.idx_scale = idx_scale
