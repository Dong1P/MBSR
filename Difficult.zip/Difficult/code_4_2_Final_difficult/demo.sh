

#Train
#python main.py --scale 4 --save EDSR_difficult_Final_x4_2_0315_retrain --reset --chop_forward   --pre_train_1 ../experiment/EDSR_bicubic_Final_x4_2_0315_update/model/model_74.pt

#
# Test your own images
python main.py --scale 4 --data_test MyImage --test_only --save_results --pre_train_1 ../../experiment/EMBSR_difficult_Final_x4_2_0315_retrain/model/model_12.pt   --self_ensemble



