
#Train
#python main.py --model EDSR --scale 1 --save DNEDSR__x4_4_0315_track3_ResDnCNN_Final_method_2 --reset # --chop_forward  # --pre_train_1 ../experiment/DEDSR__x4_4_0315_track2_Feel/model/model_30.pt #  --pre_train_1 ../experiment/EDSR_baseline_x2_1/model/model_183.pt  --pre_train_2 ../experiment/EDSR_baseline_x4_2/model/model_268.pt --pre_train_3 ../experiment/EDSR_baseline_x8_4/model/model_297.pt
#


# Test your own images
python main.py --scale 1 --data_test MyImage --test_only --save_results --pre_train_1 ../../experiment/DNResnet__x4_4_0315_track3_ResDnCNN_Final_method_2/model/model_300.pt --self_ensemble

#Advanced - JPEG artifact removal
#python main.py --template MDSR_jpeg --model MDSR --scale 2+3+4 --save MDSR_jpeg --quality 75+ --reset
